import 'package:flutter/material.dart';

class MapScreencartepays extends StatefulWidget {
  const MapScreencartepays({super.key});

  @override
  State<MapScreencartepays> createState() => _MyWidgetState();
}

class _MyWidgetState extends State<MapScreencartepays> {
  @override
  Widget build(BuildContext context) {
    return Center(
  child:     Text("data"),
    );
  }
}