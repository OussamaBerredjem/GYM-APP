class ExerciceObject{
  String name,subtitle,image,uid,pereUid;
  ExerciceObject({required this.name,required this.subtitle,required this.image,required this.uid,required this.pereUid});
}