class ReccetePlanObject{
  String title,subtitle,image,pereUid,uid;

  ReccetePlanObject({required this.title,required this.subtitle,required this.image,required this.pereUid,required this.uid});
}