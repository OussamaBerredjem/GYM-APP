




import 'package:flutter/material.dart';

class AttributeScreen extends StatelessWidget {
  const AttributeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(child: Text('Attribute Screen screen '),);
  }
}