import 'package:flutter/material.dart';

class MotDePasseOublie extends StatefulWidget {
  const MotDePasseOublie ({super.key});

  @override
  State<MotDePasseOublie> createState() => _MyWidgetState();
}

class _MyWidgetState extends State<MotDePasseOublie> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Text('data'),
    );
  }
}