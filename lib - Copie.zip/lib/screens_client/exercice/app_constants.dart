class AssetManager {
  static String banner1 = 'assets/images/banner1.jpg';
  static String banner2 = 'assets/images/banner2.jpg';
}

class AppConstants {
  static String ImagePUrl =
      "https://static.nike.com/a/images/t_PDP_864_v1/f_auto,b_rgb:f5f5f5/b7d9211c-26e7-431a-ac24-b0540fb3c00f/chaussure-air-force-1-07-pour-CFVMS0.png";

  static List<String> bannersImages = [
    AssetManager.banner1,
    AssetManager.banner2,

  ];
  




}
