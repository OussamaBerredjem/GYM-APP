class StatistiqueModel{
  String date,value;
  StatistiqueModel({required this.value,required this.date});
}