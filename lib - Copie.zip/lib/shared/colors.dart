import 'package:flutter/material.dart';

const gray = Color.fromRGBO(36, 36, 36, 0.5);

const white = Colors.white;
const black = Colors.black;
const pink = Color.fromRGBO(233, 61, 73, 1);
const blue = Color.fromRGBO(24, 119, 242, 1);
const red = Colors.red;

