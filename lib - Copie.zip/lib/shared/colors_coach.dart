import 'package:flutter/material.dart';

class MyColors {
  static const Color textColor =Color.fromRGBO(233, 61, 73, 1);

  static const Color buttonColor = Colors.blue; // Set your desired button color
}
